/*
kyzryzz.t.me
𝘒𝘺𝘻𝘙𝘺𝘻𝘻 𝘟𝘋
https://whatsapp.com/channel/0029VaRI1OB2P59cTdJKZh3q
TITENONO LEK KO HAPUS😂
*/
import fs from "fs";
let {
  proto,
  prepareWAMessageMedia,
  generateWAMessageFromContent
} = (await import("@adiwajshing/baileys")).default;
let handler = async (_0x1fb796, {
  conn,
  usedPrefix: _0x3b5a76,
  __dirname: _0x4b9109,
  args: _0x11ee05,
  command: _0x1fc7f1
}) => {
  let _0x2b92de = await _0x106242.getName(_0x1fb796.sender);
  _0x1fb796.reply("*ɴɪʜ ᴋᴀᴋ @" + _0x1fb796.sender.split("@")[0] + ", Nɪʜ ᴏᴡɴᴇʀ ғᴜʀɪɴᴀ >//<*");
  let _0x2e3815 = _0x1fb796.mentionedJid && _0x1fb796.mentionedJid[0] ? _0x1fb796.mentionedJid[0] : _0x1fb796.quoted ? _0x1fb796.quoted.sender : _0x1fb796.fromMe ? _0x106242.user.jid : _0x1fb796.sender;
  let url = "https://telegra.ph/file/d90e4a015efafe785434e.jpg";
  let kyz = "\n*▬▭▬▭▬▭▬▭▬▭▬▭▬*\n> ⌬│ ╭ *ᴏᴡɴᴇʀ* : *" + kyzryzz + nameown + kyzryzz + "*\n> ⌬│︎ ∘ *ᴡᴀ ᴏᴡɴᴇʀ* : 628\n> ⌬│︎ ∘ *ɪɴғᴏ ᴄʀᴇᴀᴛᴏʀ* : " + kyzryzz + kyzryzz + kyzryzz + sid + kyzryzz + kyzryzz + kyzryzz + "\n> ⌬│╰ *ɪɴsᴛɢʀᴀᴍ* : " + kyzryzz + kyzryzz + kyzryzz + sig + kyzryzz + kyzryzz + kyzryzz + "\n*▬▭▬▭▬▭▬▭▬▭▬▭▬*\n";
  let _0x4993dc = generateWAMessageFromContent(_0x1fb796.chat, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: kyz
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            title: "",
            subtitle: "",
            hasMediaAttachment: true,
            ...(await prepareWAMessageMedia({
              image: {
                url: url
              }
            }, {
              upload: conn.waUploadToServer
            }))
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [{
              name: "cta_url",
              buttonParamsJson: "{\"display_text\":\"Oᴡɴᴇʀ ғᴜʀɪɴᴀ - ᴀɪ 🪩\",\"url\":\"https://wa.me/" + nomorown + "\",\"merchant_url\":\"https://wa.me/" + nomorown + "\"}"
            }, {
              name: "cta_url",
              buttonParamsJson: "{\"display_text\":\"ɪɴғᴏ ʙᴏᴛ ғᴜʀɪɴᴀ - ᴀɪ 🌐\",\"url\":\"https://whatsapp.com/channel/0029VaRI1OB2P59cTdJKZh3q\",\"merchant_url\":\"https://www.google.com\"}"
            }]
          }),
          contextInfo: {
            mentionedJid: [_0x1fb796.sender],
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterName: "🔮 𝖯𝗈𝗐𝖾𝗋𝖾𝖽 𝖡𝗒 𝖪𝗒𝗓𝖱𝗒𝗓𝗓 🔮",
              newsletterJid: "120363247149539361@newsletter",
              serverMessageId: null
            }
          }
        })
      }
    }
  }, {
    quoted: m
  });
  await conn.relayMessage(msg.chat, msg.message, {
    messageId: msg.key.id
  });
  let _0x270291 = _0x2120de => new Promise(_0x5e0bab => setTimeout(_0x5e0bab, _0x2120de));
  let own = {
    audio: fs.readFileSync("./vn/ownerku.mp3"),
    mimetype: "audio/mpeg",
    ptt: true,
    viewOnce: false,
    thumbnaiUrl: thumb
  };
  await _0x270291(1000);
  conn.sendMessage(m.chat, own, {
    quoted: m
  });
};
handler.help = ["owner"];
handler.tags = ["info"];
handler.command = /^(owner)$/i;
handler.limit = true;
handler.register = true;
export default handler;
